﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

[Serializable]
public class trackedDataPoint
{
    public float time;
    public float value;

    public trackedDataPoint(float _time, float _value)
    {
        time = _time;
        value = _value;
    }
};

[Serializable]
public class trackedData
{
    public string name;
    public List<trackedDataPoint> dataPoints;

    public trackedData(string _name, List<trackedDataPoint> _dataPoints)
    {
        name = _name;
        dataPoints = _dataPoints;
    }

    public void add(float _data)
    {
        //new trackedDataPoint(Time.time, cleanData)
        dataPoints.Add(new trackedDataPoint(Time.time, _data));
    }
}